﻿namespace chainofresponsibility
{
   public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsCurrentEmployee { get; set; }
        public bool BackgroundVerificationCleared { get; set; }
        public bool IsProjectAllocated { get; set; }
        public string Designation { get; set; }

        public Employee(int id, string name, bool isCurrentEmployee, bool backgroundVerificationCleared, bool isProjectAllocated, string designation)
        {
            Id = id;
            Name = name;
            IsCurrentEmployee = isCurrentEmployee;
            BackgroundVerificationCleared = backgroundVerificationCleared;
            IsProjectAllocated = isProjectAllocated;
            Designation = designation;
        }
    }

    public interface IHandler<T> where T : class
    {
        IHandler<T> SetSuccessor(IHandler<T> successor);
        void Handle(T request);
    }

    public class EmployeeNotResignedHandler : IHandler<Employee>
    {
        private IHandler<Employee>? _successor;
        public void Handle(Employee request)
        {
            if (!request.IsCurrentEmployee)
            {
                throw new Exception("Employee has resigned");
            }
            _successor?.Handle(request);
        }

        public IHandler<Employee> SetSuccessor(IHandler<Employee> successor)
        {
            _successor=successor;
            return _successor;
        }
    }

    public class EmployeeBackgroundVerificationHandler : IHandler<Employee>
    {
        private IHandler<Employee>? _successor;
        public void Handle(Employee request)
        {
            if (!request.BackgroundVerificationCleared)
            {
                throw new Exception("Employees background verification is not cleared");
            }
            _successor?.Handle(request);
        }

        public IHandler<Employee> SetSuccessor(IHandler<Employee> successor)
        {
            _successor = successor;
            return _successor;
        }
    }

    public class EmployeeProjectAllocatedHandler : IHandler<Employee>
    {
        private IHandler<Employee>? _successor;
        public void Handle(Employee request)
        {
            if (!request.IsProjectAllocated)
            {
                throw new Exception("Employee is is bench !!");
            }
            _successor?.Handle(request);
        }

        public IHandler<Employee> SetSuccessor(IHandler<Employee> successor)
        {
            _successor = successor;
            return _successor;
        }
    }

    public class EmployeeManagerHandler : IHandler<Employee>
    {
        private IHandler<Employee>? _successor;
        public void Handle(Employee request)
        {
            if (request.Designation != "Manager")
            {
                throw new Exception("Employee is not manager !!");
            }
            Console.WriteLine("Employee is manager");
        }

        public IHandler<Employee> SetSuccessor(IHandler<Employee> successor)
        {
            _successor = successor;
            return _successor;
        }
    }
}
