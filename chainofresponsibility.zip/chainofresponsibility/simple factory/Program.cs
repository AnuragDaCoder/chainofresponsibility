﻿// See https://aka.ms/new-console-template for more information



using chainofresponsibility;

var employee1 = new Employee(123,"Anurag",true,true,true,"Manager");
var employee2 = new Employee(124,"Abhishek",true,true,true,"Developer");

var handler = new EmployeeNotResignedHandler();
handler.SetSuccessor(new EmployeeBackgroundVerificationHandler())
       .SetSuccessor(new EmployeeProjectAllocatedHandler())
       .SetSuccessor(new EmployeeManagerHandler());


try
{
    handler.Handle(employee1);
    handler.Handle(employee2);
    Console.WriteLine("Employee is valid and employee is Manager");
}
catch (Exception ex)
{
    Console.WriteLine("Employee is not valid/manager!!");
}